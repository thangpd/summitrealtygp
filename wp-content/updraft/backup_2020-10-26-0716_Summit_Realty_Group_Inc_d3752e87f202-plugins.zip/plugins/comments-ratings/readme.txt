=== Comments Ratings ===
Contributors: pixelgrade, euthelup, babbardel, vlad.olaru, raduconstantin
Tags: comments, rating, reviews
Requires at least: 4.9.0
Tested up to: 5.2.0
Stable tag: 1.1.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Convert comments into reviews for your visitors.

== Description ==

Easily add a rating system to your comments area and start displaying reviews from your visitors.

== Changelog ==

= 1.1.6 =
* We did several compatibility checks with the latest WordPress releases, so that everything will be working as smoothly as always.

= 1.1.5 =
* Fixed: the textdomain loading

= 1.1.4 =
* Improved: compatibility with WPML and other translations plugins

= 1.1.3 =
* Improved: translations strings(for real)
* Added: WordPress 4.4.0 compatibility

= 1.1.2 =
* Improved translations strings
* Fixed reviews count

= 1.1.1 =
* Fixed issues with editing and saving reviews from the WP admin
* Added the star ratings to the Comments page list in the WP admin

= 1.1.0 =
* Added Default score
* Added Labels options

= 1.0.0 =
* Init
