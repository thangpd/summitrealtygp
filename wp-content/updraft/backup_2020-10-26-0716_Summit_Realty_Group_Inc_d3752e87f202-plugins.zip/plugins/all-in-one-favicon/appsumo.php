<?php add_thickbox(); ?>
<div class="wrap">
        <script>
                window.open('https://appsumo.com/tools/wordpress/?utm_source=sumo&utm_medium=wp-widget&utm_campaign=all-in-one-favicon');
                window.history.back();
        </script>
</div>