<div class="all-in-one-favicon-appsumo-capture-container">
        <div class="">
                <div class="all-in-one-favicon-appsumo-capture-header">You’re never paying full price for software again.</div>
                <div class="all-in-one-favicon-appsumo-capture-sub-header">
                        We’ll send you the hottest deals straight to your inbox so
                        you’re always in on the best-kept software secrets.
                </div>
                <form class="signup-email-form" id="signup_email_form" method="post" action="" onsubmit="submitAppsumoCaptureForm(this.email.value);return false;">                        
                        <input type="email" id="email" name="email" placeholder="Email Address" class="all-in-one-favicon-appsumo-capture-container-input">
                        <button class="all-in-one-favicon-appsumo-capture-container-button" type="submit">Send Me Deals</button>
                </form>
        </div>
</div>