<?php
/**
 * Advanced Search IDX Template
 *
 * @package WP Pro Real Estate 7
 * @subpackage Template
 */

?>
    
<div id="advanced-search">
<?php if (is_active_sidebar('dsidxpress-homepage')) {
    dynamic_sidebar('IDX Search Homepage');
} ?>
</div>